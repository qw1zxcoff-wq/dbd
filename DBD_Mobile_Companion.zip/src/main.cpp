#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cwctype>
#include <cctype>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

static ID3D11Device* g_device = nullptr;
static ID3D11DeviceContext* g_context = nullptr;
static IDXGISwapChain* g_swapChain = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static HWND g_overlay = nullptr;
static HWND g_target = nullptr;
static bool g_showMenu = true;
static bool g_showWatermark = true;
static bool g_showKeybinds = true;
static bool g_showFps = true;
static bool g_showPing = false;
static bool g_running = true;
static bool g_useAccent = true;
static float g_alpha = 1.0f;
static float g_accent[3] = {0.88f, 0.18f, 0.20f};
static char g_targetName[128] = "MuMu";

static void CreateRenderTarget() {
    ID3D11Texture2D* backBuffer = nullptr;
    if (SUCCEEDED(g_swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) {
        g_device->CreateRenderTargetView(backBuffer, nullptr, &g_rtv);
        backBuffer->Release();
    }
}
static void CleanupRenderTarget() {
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
}
static void CleanupD3D() {
    CleanupRenderTarget();
    if (g_swapChain) { g_swapChain->Release(); g_swapChain = nullptr; }
    if (g_context) { g_context->Release(); g_context = nullptr; }
    if (g_device) { g_device->Release(); g_device = nullptr; }
}
static bool CreateDeviceD3D(HWND hwnd) {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT flags = 0;
#if defined(_DEBUG)
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    D3D_FEATURE_LEVEL level{};
    const D3D_FEATURE_LEVEL levels[] = {
        D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1,
        D3D_FEATURE_LEVEL_10_0
    };
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
        levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &sd,
        &g_swapChain, &g_device, &level, &g_context);
    if (FAILED(hr)) return false;
    CreateRenderTarget();
    return g_rtv != nullptr;
}

static std::wstring ToLower(std::wstring s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](wchar_t c) { return (wchar_t)towlower(c); });
    return s;
}
static BOOL CALLBACK FindTargetEnum(HWND hwnd, LPARAM) {
    if (!IsWindowVisible(hwnd)) return TRUE;
    wchar_t title[512]{};
    GetWindowTextW(hwnd, title, ARRAYSIZE(title));
    std::wstring t = ToLower(title);
    std::wstring q = ToLower(std::wstring(g_targetName, g_targetName + strlen(g_targetName)));
    if (!t.empty() && t.find(q) != std::wstring::npos) {
        g_target = hwnd;
        return FALSE;
    }
    return TRUE;
}
static HWND FindTargetWindow() {
    g_target = nullptr;
    EnumWindows(FindTargetEnum, 0);
    return g_target;
}
static void UpdateOverlayBounds() {
    if (!g_target || !IsWindow(g_target)) g_target = FindTargetWindow();
    if (!g_target) return;

    RECT rc{};
    if (!GetClientRect(g_target, &rc)) return;
    POINT p{ rc.left, rc.top };
    ClientToScreen(g_target, &p);
    int width = rc.right - rc.left;
    int height = rc.bottom - rc.top;
    if (width <= 0 || height <= 0) return;

    SetWindowPos(g_overlay, HWND_TOPMOST, p.x, p.y, width, height,
        SWP_NOACTIVATE | SWP_SHOWWINDOW);
}
static void SetInputMode() {
    LONG_PTR ex = GetWindowLongPtrW(g_overlay, GWL_EXSTYLE);
    if (g_showMenu) ex &= ~WS_EX_TRANSPARENT;
    else ex |= WS_EX_TRANSPARENT;
    SetWindowLongPtrW(g_overlay, GWL_EXSTYLE, ex);
}
static void ApplyStyle() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 7.0f;
    s.ChildRounding = 6.0f;
    s.FrameRounding = 4.0f;
    s.PopupRounding = 5.0f;
    s.ScrollbarRounding = 6.0f;
    s.WindowBorderSize = 1.0f;
    s.FrameBorderSize = 0.0f;
    s.ItemSpacing = ImVec2(10, 8);
    s.WindowPadding = ImVec2(14, 13);

    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = ImVec4(0.93f, 0.93f, 0.95f, 1.0f);
    c[ImGuiCol_TextDisabled] = ImVec4(0.48f, 0.49f, 0.53f, 1.0f);
    c[ImGuiCol_WindowBg] = ImVec4(0.055f, 0.057f, 0.065f, 0.97f);
    c[ImGuiCol_ChildBg] = ImVec4(0.075f, 0.078f, 0.087f, 1.0f);
    c[ImGuiCol_Border] = ImVec4(0.17f, 0.18f, 0.20f, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(0.12f, 0.125f, 0.14f, 1.0f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.17f, 0.18f, 0.20f, 1.0f);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.20f, 0.21f, 0.23f, 1.0f);
    c[ImGuiCol_Button] = ImVec4(0.14f, 0.145f, 0.16f, 1.0f);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.20f, 0.21f, 0.23f, 1.0f);
    c[ImGuiCol_ButtonActive] = ImVec4(0.24f, 0.25f, 0.27f, 1.0f);
    c[ImGuiCol_Header] = ImVec4(0.16f, 0.17f, 0.19f, 1.0f);
    c[ImGuiCol_HeaderHovered] = ImVec4(0.21f, 0.22f, 0.24f, 1.0f);
    c[ImGuiCol_HeaderActive] = ImVec4(0.25f, 0.26f, 0.28f, 1.0f);
    c[ImGuiCol_CheckMark] = ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.0f);
    c[ImGuiCol_SliderGrab] = ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.0f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.0f);
    c[ImGuiCol_Separator] = ImVec4(0.20f, 0.20f, 0.22f, 1.0f);
}

static void DrawWatermark() {
    if (!g_showWatermark) return;
    ImGui::SetNextWindowPos(ImVec2(14, 12), ImGuiCond_Once);
    ImGui::SetNextWindowBgAlpha(0.88f);
    ImGui::Begin("##watermark", nullptr,
        ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoSavedSettings);
    ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1), "DBD");
    ImGui::SameLine();
    ImGui::Text("COMPANION");
    ImGui::SameLine();
    ImGui::TextDisabled("|");
    if (g_showFps) {
        ImGui::SameLine();
        ImGui::Text("%.0f FPS", ImGui::GetIO().Framerate);
    }
    ImGui::End();
}
static void DrawKeybinds() {
    if (!g_showKeybinds) return;
    ImGui::SetNextWindowPos(ImVec2(14, 60), ImGuiCond_Once);
    ImGui::SetNextWindowBgAlpha(0.88f);
    ImGui::Begin("Keybinds", &g_showKeybinds,
        ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);
    ImGui::TextDisabled("INSERT");
    ImGui::SameLine(90);
    ImGui::Text("Toggle menu");
    ImGui::End();
}
static void DrawMenu() {
    if (!g_showMenu) return;
    ImGui::SetNextWindowSize(ImVec2(570, 440), ImGuiCond_FirstUseEver);
    ImGui::Begin("DBD Mobile Companion", &g_showMenu);
    ImGui::TextDisabled("WINDOWS OVERLAY  /  MUMU PLAYER");
    ImGui::Separator();

    static int tab = 0;
    const char* tabs[] = { "Overview", "Visuals", "HUD", "Settings" };
    for (int i = 0; i < 4; ++i) {
        if (i) ImGui::SameLine();
        if (ImGui::Selectable(tabs[i], tab == i, 0, ImVec2(124, 28))) tab = i;
    }
    ImGui::Spacing();

    if (tab == 0) {
        ImGui::Text("Companion status");
        ImGui::BulletText("Overlay renderer: Direct3D 11 + Dear ImGui");
        ImGui::BulletText("Target: %s", g_target && IsWindow(g_target) ? "MuMu window found" : "Waiting for MuMu");
        ImGui::BulletText("Input: %s", g_showMenu ? "Interactive" : "Click-through");
        ImGui::Spacing();
        ImGui::TextWrapped("This companion is an independent desktop overlay. It does not read or modify Dead by Daylight Mobile memory.");
        ImGui::Spacing();
        if (ImGui::Button("Find MuMu window", ImVec2(170, 30))) g_target = FindTargetWindow();
        ImGui::SameLine();
        if (ImGui::Button("Hide menu", ImVec2(120, 30))) g_showMenu = false;
    } else if (tab == 1) {
        ImGui::Text("Visual overlay options");
        ImGui::TextWrapped("These are UI demonstration toggles. Player boxes, skeletons and through-wall ESP require authorized game-provided entity data; this external companion does not obtain that data from DBD Mobile.");
        static bool demoBoxes = false, demoLines = false, demoDistance = false;
        ImGui::Checkbox("Demo box (sample only)", &demoBoxes);
        ImGui::Checkbox("Demo snapline (sample only)", &demoLines);
        ImGui::Checkbox("Demo distance label (sample only)", &demoDistance);
        ImGui::TextDisabled("No live player tracking is performed.");
    } else if (tab == 2) {
        ImGui::Checkbox("Watermark", &g_showWatermark);
        ImGui::Checkbox("Keybind list", &g_showKeybinds);
        ImGui::Checkbox("FPS counter", &g_showFps);
        ImGui::BeginDisabled();
        ImGui::Checkbox("In-game ping (no data source)", &g_showPing);
        ImGui::EndDisabled();
        ImGui::TextDisabled("FPS is measured by this overlay, not by the game.");
    } else if (tab == 3) {
        ImGui::Text("Overlay settings");
        ImGui::SliderFloat("UI opacity", &g_alpha, 0.55f, 1.0f, "%.2f");
        ImGui::ColorEdit3("Accent", g_accent);
        ImGui::InputText("Window title contains", g_targetName, sizeof(g_targetName));
        if (ImGui::Button("Re-detect target")) g_target = FindTargetWindow();
        ImGui::TextDisabled("Menu hotkey: INSERT");
        ImGui::TextDisabled("Exit: ALT + F4");
    }
    ImGui::End();
}
static void RenderFrame() {
    ImGui::GetStyle().Alpha = g_alpha;
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    DrawWatermark();
    DrawKeybinds();
    DrawMenu();

    ImGui::Render();
    const float clear[4] = { 0.f, 0.f, 0.f, 1.f };
    g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
    g_context->ClearRenderTargetView(g_rtv, clear);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    g_swapChain->Present(1, 0);
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);
static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam))
        return TRUE;
    switch (msg) {
    case WM_SIZE:
        if (g_device && wParam != SIZE_MINIMIZED) {
            CleanupRenderTarget();
            g_swapChain->ResizeBuffers(0, LOWORD(lParam), HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}
int APIENTRY wWinMain(HINSTANCE instance, HINSTANCE, LPWSTR, int) {
    WNDCLASSEXW wc{ sizeof(wc), CS_CLASSDC, WndProc, 0, 0, instance,
        nullptr, nullptr, nullptr, nullptr, L"DBDCompanionOverlay", nullptr };
    RegisterClassExW(&wc);

    g_overlay = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
        wc.lpszClassName, L"DBD Mobile Companion",
        WS_POPUP, 100, 100, 800, 600, nullptr, nullptr, instance, nullptr);
    if (!g_overlay) return 1;

    // Black is the transparent color key; ImGui draws only its own UI.
    SetLayeredWindowAttributes(g_overlay, RGB(0, 0, 0), 0, LWA_COLORKEY);
    MARGINS margins = { -1 };
    DwmExtendFrameIntoClientArea(g_overlay, &margins);

    if (!CreateDeviceD3D(g_overlay)) {
        CleanupD3D();
        DestroyWindow(g_overlay);
        UnregisterClassW(wc.lpszClassName, instance);
        return 1;
    }

    ShowWindow(g_overlay, SW_SHOW);
    UpdateWindow(g_overlay);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ApplyStyle();
    ImGui_ImplWin32_Init(g_overlay);
    ImGui_ImplDX11_Init(g_device, g_context);

    g_target = FindTargetWindow();
    MSG msg{};
    while (g_running) {
        while (PeekMessageW(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) g_running = false;
        }
        if (!g_running) break;

        if (GetAsyncKeyState(VK_INSERT) & 1) {
            g_showMenu = !g_showMenu;
            SetInputMode();
        }
        if (GetAsyncKeyState(VK_END) & 1) g_running = false;

        UpdateOverlayBounds();
        SetInputMode();

        if (!g_target || IsIconic(g_target)) {
            ShowWindow(g_overlay, SW_HIDE);
            Sleep(80);
            continue;
        }
        ShowWindow(g_overlay, SW_SHOWNA);
        RenderFrame();
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupD3D();
    DestroyWindow(g_overlay);
    UnregisterClassW(wc.lpszClassName, instance);
    return 0;
}
