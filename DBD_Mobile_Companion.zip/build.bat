@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake not found. Install CMake and add it to PATH.
  pause
  exit /b 1
)
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: Git not found. Install Git for Windows and add it to PATH.
  pause
  exit /b 1
)
if not exist build mkdir build
cmake -S . -B build -A x64
if errorlevel 1 (
  echo CMake configure failed. Install Visual Studio Build Tools with Desktop development with C++.
  pause
  exit /b 1
)
cmake --build build --config Release
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Build complete: build\Release\DBD_Mobile_Companion.exe
pause
